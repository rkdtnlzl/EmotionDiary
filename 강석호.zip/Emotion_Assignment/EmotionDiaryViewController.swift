//
//  ViewController.swift
//  Emotion_Assignment
//
//  Created by 강석호 on 5/17/24.
//

import UIKit

class EmotionDiaryViewController: UIViewController {

    //MARK: - Outlet Property
    @IBOutlet var happyLabel: UILabel!
    @IBOutlet var loveLabel: UILabel!
    @IBOutlet var likeLabel: UILabel!
    @IBOutlet var embarrassLabel: UILabel!
    @IBOutlet var sadLabel: UILabel!
    @IBOutlet var depressLabel: UILabel!
    @IBOutlet var boredLabel: UILabel!
    @IBOutlet var sickLabel: UILabel!
    @IBOutlet var sleepyLabel: UILabel!
    
    @IBOutlet var resetButton: UIButton!
    var points = [0,0,0,0,0,0,0,0,0]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resetButton.layer.cornerRadius = 10
        
        happyLabel.text = "행복해 \(points[0])"
        loveLabel.text = "사랑해 \(points[1])"
        likeLabel.text = "좋아해 \(points[2])"
        embarrassLabel.text = "당황해 \(points[3])"
        sadLabel.text = "속상해 \(points[4])"
        depressLabel.text = "우울해 \(points[5])"
        boredLabel.text = "지루해 \(points[6])"
        sickLabel.text = "아프다해 \(points[7])"
        sleepyLabel.text = "졸리다해 \(points[8])"
    }

    //MARK: - Action
    
    @IBAction func happyButtonClicked(_ sender: UIButton) {
        points[0] += 1
        happyLabel.text = "행복해 \(points[0])"
    }
    
    @IBAction func loveButtonClicked(_ sender: UIButton) {
        points[1] += 1
        loveLabel.text = "사랑해 \(points[1])"
    }
    
    @IBAction func likeButtonClicked(_ sender: UIButton) {
        points[2] += 1
        likeLabel.text = "좋아해 \(points[2])"
    }
    
    @IBAction func embarrassButtonClicked(_ sender: UIButton) {
        points[3] += 1
        embarrassLabel.text = "당황해 \(points[3])"
        
    }
    @IBAction func sadButtonClicked(_ sender: UIButton) {
        points[4] += 1
        sadLabel.text = "속상해 \(points[4])"
    }
    
    @IBAction func depressButtonClicked(_ sender: UIButton) {
        points[5] += 1
        depressLabel.text = "우울해 \(points[5])"
    }
    
    @IBAction func boredButtonClicked(_ sender: UIButton) {
        points[6] += 1
        boredLabel.text = "심심해 \(points[6])"
    }
    
    @IBAction func sickButtonClicked(_ sender: UIButton) {
        points[7] += 1
        sickLabel.text = "아프다해 \(points[7])"
    }
    
    @IBAction func sleepyButtonClicked(_ sender: UIButton) {
        points[8] += 1
        sleepyLabel.text = "졸리다해 \(points[8])"
    }
    
    @IBAction func resetButtonClicked(_ sender: UIButton) {
        
        points = [0,0,0,0,0,0,0,0,0]
        
        happyLabel.text = "행복해 \(points[0])"
        loveLabel.text = "사랑해 \(points[1])"
        likeLabel.text = "좋아해 \(points[2])"
        embarrassLabel.text = "당황해 \(points[3])"
        sadLabel.text = "속상해 \(points[4])"
        depressLabel.text = "우울해 \(points[5])"
        boredLabel.text = "지루해 \(points[6])"
        sickLabel.text = "아프다해 \(points[7])"
        sleepyLabel.text = "졸리다해 \(points[8])"
    }
    
    
}

