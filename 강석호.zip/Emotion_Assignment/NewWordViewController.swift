//
//  NewWordViewController.swift
//  Emotion_Assignment
//
//  Created by 강석호 on 5/18/24.
//

import UIKit

class NewWordViewController: UIViewController {
    
    //MARK: - Outlet Property
    @IBOutlet var searchTextField: UITextField!
    @IBOutlet var searchButton: UIButton!
    @IBOutlet var firstButton: UIButton!
    @IBOutlet var secondButton: UIButton!
    @IBOutlet var thirdButton: UIButton!
    @IBOutlet var fourthButton: UIButton!
    
    @IBOutlet var resultLabel: UILabel!
    
    var newWordList = ["윰차":"구독자 유뮤를 차별한다는 뜻" ,
                       "실매":"실시간 매니저라는 뜻",
                       "만반잘부":"만나서 반갑고 잘 부탁해 라는 뜻",
                       "꾸안꾸":"꾸민듯 안꾸민듯 이란 뜻",
                       "긁" : "긁혔냐? 라는 뜻",
                       "킹받네" : "열받았다 라는 뜻",
                       "당모치" : "당연히 모든 치킨은 옳다 라는 뜻"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchTextField.attributedPlaceholder = NSAttributedString(string: "신조어를 검색하시오", attributes: [NSAttributedString.Key.foregroundColor : UIColor.gray])
        
        firstButton.setTitle("윰차", for: .normal)
        firstButton.layer.borderColor = UIColor.black.cgColor
        firstButton.layer.borderWidth = 1
        firstButton.layer.cornerRadius = 10
        
        secondButton.setTitle("실매", for: .normal)
        secondButton.layer.borderColor = UIColor.black.cgColor
        secondButton.layer.borderWidth = 1
        secondButton.layer.cornerRadius = 10
        
        thirdButton.setTitle("만만잘부", for: .normal)
        thirdButton.layer.borderColor = UIColor.black.cgColor
        thirdButton.layer.borderWidth = 1
        thirdButton.layer.cornerRadius = 10
        
        fourthButton.setTitle("꾸안꾸", for: .normal)
        fourthButton.layer.borderColor = UIColor.black.cgColor
        fourthButton.layer.borderWidth = 1
        fourthButton.layer.cornerRadius = 10
    }
    
    //MARK: - Action
    @IBAction func searchButtonClicked(_ sender: UIButton) {
        if let searchText = searchTextField.text, !searchText.isEmpty {
            if let meaning = newWordList[searchText] {
                resultLabel.text = meaning
            } else {
                resultLabel.text = "해당 단어를 찾을 수 없습니다."
            }
        } else {
            resultLabel.text = "단어를 입력해주세요."
        }
    }
    
    @IBAction func firstButtonClicked(_ sender: UIButton) {
        searchTextField.text = "윰차"
    }
    
    @IBAction func secondButtonClicked(_ sender: UIButton) {
        searchTextField.text = "실매"
    }
    
    @IBAction func thirdButtonClicked(_ sender: UIButton) {
        searchTextField.text = "만반잘부"
    }
    
    @IBAction func fourthButtonClicked(_ sender: UIButton) {
        searchTextField.text = "꾸안꾸"
    }
    
    @IBAction func searchTextFieldClicked(_ sender: Any) {
    }
    
}
